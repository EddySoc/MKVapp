from .test import diskinfo, show_disk_info
