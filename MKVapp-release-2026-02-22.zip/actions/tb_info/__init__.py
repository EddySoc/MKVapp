from .tbinfo_actions import clear_tb_info
