"""Utility scripts moved out of package root.

Place for small CLI/debug scripts not imported by the app.
"""
